// Séparateur du CSV (virgule ici, comme dans le fichier INSEE)
const sep = ',';

/*
  Lit une ligne CSV et retourne un tableau de valeurs.
  Gère les champs entre guillemets.
*/
function getCsvValuesFromLine(line) {
    var result = [];
    var current = '';
    var inQuotes = false;
    for (var i = 0; i < line.length; i++) {
        var c = line[i];
        if (c === '"') {
            inQuotes = !inQuotes;
        } else if (c === sep && !inQuotes) {
            result.push(current.trim());
            current = '';
        } else {
            current += c;
        }
    }
    result.push(current.trim());
    return result;
}

/*
  Transforme les lignes brutes du CSV en liste d'objets JS.
  Première ligne = headers.
*/
function getLinesFromCSV(lines) {
    var headers = getCsvValuesFromLine(lines[0]);
    var data = [];
    for (var i = 1; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        var vals = getCsvValuesFromLine(lines[i]);
        var obj = {};
        for (var j = 0; j < headers.length; j++) {
            obj[headers[j]] = vals[j] !== undefined ? vals[j] : '';
        }
        data.push(obj);
    }
    return data;
}

// Variable globale pour le contenu CSV
var CSVcontent = null;

// FileReader
const fileInput = document.getElementById('csv');
const readFile = () => {
    const reader = new FileReader();
    reader.onload = () => {
        CSVcontent = reader.result;
    };
    reader.readAsText(fileInput.files[0], 'utf-8');
};

// Bouton Load
var btn = document.getElementById('load_btn');
btn.onclick = function () {
    if (!CSVcontent) {
        alert("Veuillez d'abord sélectionner le fichier CSV !");
        return;
    }
    document.getElementById('loading-msg').style.display = 'block';
    document.getElementById('dashboard').style.display = 'none';

    setTimeout(function () {
        var lines = CSVcontent.split('\n');
        var all_datas = getLinesFromCSV(lines);
        run(all_datas);
        document.getElementById('loading-msg').style.display = 'none';
        document.getElementById('dashboard').style.display = 'block';
    }, 100);
};

fileInput.addEventListener('change', readFile);
