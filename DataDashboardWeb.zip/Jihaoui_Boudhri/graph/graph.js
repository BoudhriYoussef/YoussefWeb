const sep = ','; /* variable constante permettant de séparer les objets de mon fichier csv donnée */
let allData = []; /* UNE VARIABLE QUI PERMET DE STOCKER TOUTES LES DONNEES SAISIES PAR LUTILISATEUR */

/*
Fonction : getCsvValuesFromLine (utilisée dans readfile.js donnée par le prof)

    Rôle :
    Découper une ligne du fichier CSV en différentes valeurs en utilisant
    le séparateur défini (ici la virgule). Elle nettoie aussi les guillemets
    et les espaces inutiles.

    Parametre :
    line : chaîne de caractères correspondant à une ligne du fichier CSV.

    Resultat :
    Retourne un tableau contenant les différentes valeurs de la ligne.
    Chaque élément du tableau correspond à une colonne du CSV.
*/
function getCsvValuesFromLine(line) {
    var values = line.split(sep);
    values = values.map(function(value){
        return value.replace(/\"/g, '').trim();
    });
    return values;
}

/*
    Fonction : getLinesFromHTML (utilisée dans readfile.js donnée par le prof)

    Rôle :
    Transformer le contenu du fichier CSV en une liste d’objets JavaScript.
    Chaque objet représente une commune et chaque propriété correspond
    à une colonne du fichier CSV.

    Parametre :
    lines : tableau contenant toutes les lignes du fichier CSV.

    Resultat :
    Retourne un tableau d’objets.
*/
function getLinesFromHTML(lines){
    // On récupère la première ligne comme header et on la retire
    var headers = getCsvValuesFromLine(lines[0]);
    lines.shift();

    var people = [];
    for(var i=0; i<lines.length; i+=1){
        people[i] = {};
        var lineValues = getCsvValuesFromLine(lines[i]);
        for (var j=0; j<lineValues.length; j+=1){
            people[i][headers[j]] = lineValues[j];
        }
    }
    return people;
}

// Variable globale pour le contenu du CSV
var CSVcontent;

// Filereader pour le flux de lecture (insipiré de readfile.js donnée par le prof)
const fileInput = document.getElementById('csv');
let readFile = () => {

    let reader = new FileReader();

    reader.onload = () => {

        let lines = reader.result.split('\n');
        let newData = getLinesFromHTML(lines);

        // J'ajoute les nouvelles données aux anciennes (concatination)
        allData = allData.concat(newData);

        console.log("Nombre total de communes :", allData.length);

    };

    reader.readAsText(fileInput.files[0]);
};

fileInput.addEventListener('change', readFile);

// Bouton load lié au fonction qui permet d'afficher en un seul coup le tableau de bord incluant les indicateur
var btn = document.getElementById("load");
btn.addEventListener("click", function(){

    if(allData.length === 0){
        alert("Veuillez charger un CSV.");
        return;
    }


    var data = allData;
    let revenuMin = document.getElementById("filtreRevenu").value;
    /*option filtrage */
    if(revenuMin){
        data = data.filter(d => Number(d["revenumedian"]) >= revenuMin);
    }
    // Histogramme revenu médian
    let revenuMedian = data.map(d => Number(d["revenumedian"])).filter(v => !isNaN(v));
    tracerhist(revenuMedian);
    /*
        Fonction : tracerhist

        Rôle :
        Tracer un histogramme représentant la distribution du revenu médian
        des communes. Ce graphique permet de visualiser combien de communes
        se situent dans chaque intervalle de revenu.

        Parametre :
        tab : tableau contenant les revenus médians des communes (valeurs numeriques).

        Graphique obtenu :
        Histogramme avec :
        - axe X : revenu médian (€)
        - axe Y : nombre de communes
    */
    function tracerhist(tab){
        var trace = {x: tab, type:'histogram', marker:{color:'#007bff'}};
        var layout = {title :"revenu médian par commune", xaxis:{title:"Revenu médian (€)"}, yaxis:{title:"Nombre de communes"},margin:{t:40,l:80,r:20,b:40}};
        Plotly.newPlot('hist', [trace], layout, {responsive:true});
    }


    // Top 10 communes riches et pauvres 

    let tableau = data.map(d=>({commune:d["Nom géographique"], revenu:Number(d["revenumedian"])}))
                     .filter(d=>!isNaN(d.revenu))
                     .sort( (a,b)=>b.revenu-a.revenu );
    let top10Haut = tableau.slice(0,10);
    let top10Bas = tableau.slice(-10);

    tracerTopCommunes(
        top10Haut.map(d=>d.commune),
        top10Haut.map(d=>d.revenu),
        top10Bas.map(d=>d.commune),
        top10Bas.map(d=>d.revenu)
    );
    /*
    Fonction : tracerTopCommunes

        Rôle :
        Afficher un diagramme en barres comparant :
        - les 10 communes avec les revenus médians les plus élevés
        - les 10 communes avec les revenus médians les plus faibles.

        Parametres :
        communesHaut : tableau contenant les noms des 10 communes les plus riches.
        revenusHaut : tableau contenant les revenus médians correspondants.

        communesBas : tableau contenant les noms des 10 communes les plus pauvres.
        revenusBas : tableau contenant leurs revenus médians.

        Graphique obtenu :
        Diagramme en barres avec deux couleurs :
        - en bleu : communes les plus riches
        - en rouge : communes les plus pauvres
    */
    function tracerTopCommunes(communesHaut, revenusHaut, communesBas, revenusBas){
        var trace1 = {x:communesHaut, y:revenusHaut, type:'bar', name:'Top 10 riches', marker:{color:'#007bff'}};
        var trace2 = {x:communesBas, y:revenusBas, type:'bar', name:'Top 10 pauvres', marker:{color:'#ff4d4d'}};
        var layout = {title:"Top 10 communes riches et pauvres",xaxis:{title:"Communes"}, yaxis:{title:"Revenu médian (€)"}, margin:{t:40,l:80,r:20,b:200}};
        Plotly.newPlot('topcommunes',[trace1,trace2],layout,{responsive:true});
    }



    //  Nuage de points revenu vs Gini
    let scatterData = data.filter(d=>d["revenumedian"] && d["indiceGini"]);
    tracerNuage(
    scatterData.map(d => Number(d["revenumedian"])),
    scatterData.map(d => Number(d["indiceGini"]))
    );

    /*
        Fonction : tracerNuage

        Rôle :
        Tracer un nuage de points pour analyser la relation entre
        le revenu médian et l’indice de Gini (inégalité des revenus).

        Paramètres :
        revenus : tableau contenant les revenus médians des communes.
        ginis : tableau contenant les indices de Gini correspondants.

        Graphique obtenu :
        Scatter plot :
        - axe X : revenu médian
        - axe Y : indice de Gini
        Chaque point représente une commune.
        Ce graphique permet d'observer s’il existe une corrélation
        entre richesse et inégalités.
    */
    function tracerNuage(revenus, ginis){
        var trace = {x:revenus, y:ginis, mode:'markers', type:'scatter', marker:{color:'#6f42c1', size:6}};
        var layout = {title:"Revenu médian vs Indice de Gini", xaxis:{title:"Revenu médian (€)"}, yaxis:{title:"Indice de Gini"}, margin:{t:40,l:80,r:50,b:50}};
        Plotly.newPlot('nuage',[trace],layout,{responsive:true});
    }


    // Histogramme indice de Gini 
    let ginis = data.map(d=>Number(d["indiceGini"])).filter(v=>!isNaN(v));
    tracerHistGini(ginis);

    /*
    Fonction : tracerHistGini
        Rôle :
        Tracer un histogramme montrant la distribution des indices
        de Gini pour l'ensemble des communes.

        Paramètre :
        tab → tableau contenant les indices de Gini.

        Graphique obtenu :
        Histogramme avec :
        - axe X : indice de Gini
        - axe Y : nombre de communes
        Permet de visualiser la répartition des inégalités de revenus.
    */
    function tracerHistGini(tab){
        var trace = {x:tab, type:'histogram', marker:{color:'#ff7f0e'}};
        var layout = {title:"Distribution de l'indice de Gini", xaxis:{title:"Indice de Gini"}, yaxis:{title:"Nombre de communes"}, margin:{t:40,l:80,r:20,b:40}};
        Plotly.newPlot('distribgini',[trace],layout,{responsive:true});
    }

    //  Pie chart structure moyenne des revenus 
    tracerPieRevenusMoyenne(data);

    /*
    Fonction : tracerPieRevenusMoyenne

        Rôle :
        Calculer la structure moyenne des revenus des communes et
        l’afficher sous forme de diagramme circulaire.

        Les pourcentages étant donnés pour chaque commune,
        la fonction calcule la moyenne de chaque type de revenu.

        Paramètre :
        data : tableau d’objets contenant toutes les communes 
        et leurs différentes catégories de revenus.

        Graphique obtenu :
        Diagramme circulaire représentant la structure moyenne des revenus :
        - revenu d'activité
        - revenu de pension
        - revenu de patrimoine
        Les parts sont exprimées en pourcentage.
    */
    function tracerPieRevenusMoyenne(data){
        let categories = ["revenu d'activité", "revenu de pension", "revenu de patrimoine"];
        let totals = [0,0,0]; let count=0;
        for(let d of data){
            if(d[categories[0]] && d[categories[1]] && d[categories[2]]){
                totals[0]+=Number(d[categories[0]]);
                totals[1]+=Number(d[categories[1]]);
                totals[2]+=Number(d[categories[2]]);
                count++;
            }
        }
        let moyennes = totals.map(t => t / count);
        var trace = {
            labels:["Revenu d'activité","Revenu de pension","Revenu de patrimoine"],
            values:moyennes,
            type:'pie',
            marker:{colors:['#1f77b4','#ff7f0e','#2ca02c']},
            textinfo:"label+percent",
            hoverinfo:"label+value+percent"
        };
        var layout = {title:"Structure moyenne des revenus (%)", margin:{t:40,l:200,r:20,b:20}};
        Plotly.newPlot('revenusPie',[trace],layout,{responsive:true});
    }

});
