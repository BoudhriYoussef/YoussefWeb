<!DOCTYPE html>
<html>
    <body>
        <h1>Bienvenue, que souhaitez vous voir ? </h1>
        <form>
            <a href='liste_vols.php'>Vols</a><br><br>
            <a href='liste_passagers.php'>Passagers</a><br><br>
            <a href='modification_vol.php'>Avions<br><br> 
        </form>
    </body>
</html>