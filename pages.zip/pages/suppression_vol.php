<!DOCTYPE html>
<html>
    <head>
        <title>Annuler un vol</title>
        <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
    </head>
    <body>

    <?php

        include("connexion.php");
        $con = connect();

        if(!$con){
            echo "<p>Erreur connexion </p>";
            exit;
        }

        if(!isset($_GET['refvol'])){
            echo "<p>Aucun vol sélectionné.</p>";
            exit;
        }

        $refvol = $_GET['refvol'];

        // Récupération du vol
        $sql = "SELECT * FROM vol WHERE refvol = $1";
        $res = pg_query_params($con, $sql, array($refvol));

        if(pg_num_rows($res) == 0){
            echo "<p>Vol introuvable.</p>";
            exit;
        }

        $vol = pg_fetch_array($res);

        $sql_update = "UPDATE vol SET statut = 'Annulé' WHERE refvol = $1";
        $res_update = pg_query_params($con, $sql_update, array($refvol));

        if($res_update){
            echo "<p>Le vol a été annulé avec succès.</p>";
            echo "<a href='liste_vols.php'><button>Retour à la liste</button></a>";
        } else {
            echo "<p>Erreur : ".pg_last_error($con)."</p>";
        }

    ?>

    </body>
</html>
