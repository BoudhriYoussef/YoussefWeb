<!DOCTYPE html>
<html>
<body>

<?php

// Connexion BD
include("connexion.php");
$connect = connect();

if (!$connect){
    echo "Erreur de connexion";
    exit;
}

// Récupération des valeurs POST
$nbsieges     = $_POST['nbsieges'];
$reftype      = $_POST['reftype'];
$date_service = $_POST['date_service'];
$idca         = $_POST['idca'];

if (!$nbsieges || !$reftype || !$date_service || !$idca){
    echo "MANQUE D'INFORMATIONS ! SAISISSEZ TOUTES LES INFORMATIONS DE L'AVION À AJOUTER SVP";
    exit;
}
//  Récupérer le dernier ID avion

$sql_last = "SELECT idavion FROM avion ORDER BY idavion DESC LIMIT 1";
$res_last = pg_query($connect, $sql_last);
$last_row = pg_fetch_array($res_last);

if ($last_row) {
    $last_id = $last_row['idavion'];   // ex : "AV12"
    $num = intval(substr($last_id, 2)); // extrait 12
    $new_num = $num + 1;                // 13
    $new_id = "AV".$new_num;            // "AV13"
} else {
    // Si aucun avion n’existe encore :
    $new_id = "AV0";
}

// Vérifie si la date existe déjà
$sql_check = "SELECT * FROM date_service WHERE miseservice = '$date_service'";
$res_check = pg_query($connect, $sql_check);

if (pg_num_rows($res_check) == 0) {
    // Insère la nouvelle date dans la table de référence
    $sql_insert_date = "INSERT INTO date_service (miseservice) VALUES ('$date_service')";
    pg_query($connect, $sql_insert_date);
}



// AJOUT DE L'AVION AVEC INSERT
$sql1 = "
    INSERT INTO avion (idavion,nbsieges, reftype, miseservice, idca)
    VALUES ('$new_id','$nbsieges', '$reftype', '$date_service', '$idca')
";

$result = pg_query($connect, $sql1);

if (!$result){
    echo "<p style='color:red'>Erreur SQL : " . pg_last_error($connect) . "</p>";
    exit;
}

echo "<h2 style='color:green;'>✔ Avion ajouté avec succès !</h2>";

?>

</body>
</html>
