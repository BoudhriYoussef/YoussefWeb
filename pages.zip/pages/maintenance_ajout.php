<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<?php

// Connexion BD
include("connexion.php");
$connect = connect();


if (!$connect){
    echo "Erreur de connexion";
    exit;
}

// Récupération des valeurs POST
$date_maint     = $_POST['date_maint'];
$maint_descrip      = $_POST['maintdescrip'];
$idavion = $_POST['idavion'];
$idemploye         = $_POST['idemploye'];

if (!$date_maint || !$maint_descrip || !$idavion || !$idemploye ){
    echo "MANQUE D'INFORMATIONS ! SAISISSEZ TOUTES LES INFORMATIONS DE L'AVION À AJOUTER SVP";
    exit;
}
//  Récupérer le dernier ID maintenance

$sql_last = "SELECT refmaint FROM MAINTENANCE ORDER BY refmaint DESC LIMIT 1";
$res_last = pg_query($connect, $sql_last);
$last_row = pg_fetch_array($res_last);

if ($last_row) {
    $last_id = $last_row['refmaint'];   // ex : "M01"
    $num = intval(substr($last_id, 1)); // extrait 01
    $new_num = $num + 1;                // 02
    $new_id = "M0".$new_num;            // "AV13"
} else {
    // Si aucun avion n’existe encore :
    $new_id = "M01";
}

// AJOUT DE L'AVION AVEC INSERT
$sql1 = "
    INSERT INTO MAINTENANCE (refmaint,datemaint, description, idavion, idemploye)
    VALUES ('$new_id','$date_maint', '$maint_descrip', '$idavion', '$idemploye')
";

$result = pg_query($connect, $sql1);

if (!$result){
    echo "<p style='color:red'>Erreur SQL : " . pg_last_error($connect) . "</p>";
    exit;
}

echo "<h2 style='color:green;'>✔ Maintenance ajouté avec succès !</h2>";

?>

</body>
</html>
