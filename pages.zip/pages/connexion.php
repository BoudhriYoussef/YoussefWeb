<?php
function connect()
{
$con=pg_connect("host=serveur-etu.polytech-lille.fr user=nbachira password=postgres dbname=projet_bd") ;
return $con;
}
?>