<!DOCTYPE html>
<html>
<body>

<?php
include("connexion.php");
$connect = connect();

if (!$connect){
    echo "Erreur de connexion";
    exit;
}
echo "<form method='POST' action='avions_supression.php'>";

?>

<table border='2' width='600px'>

<tr>
        <td> Id de l'avion à supprimer </td>
        <td>
            <select name="idavion" size="1">
                <?php
                $sql = "SELECT idavion FROM AVION";
                $result = pg_query($connect, $sql);

                while ($row = pg_fetch_array($result)) {
                    echo "<option value='".$row['idavion']."'>".$row['idavion']."</option>";
                }
                ?>
            </select>
        </td>
</tr>

</table>
<br><input type='submit' value='Supprime l'avion'>

</form>



</body>
</html>
