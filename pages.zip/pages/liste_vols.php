<!DOCTYPE html>
<html>
    <head>
        <title>Liste des vols</title>
        <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
    </head>
    <body>

    <h1>Liste des Vols</h1>

    <?php
    include("connexion.php");
    $con = connect();

    if (!$con){
        echo "Problème de connexion à la base";
        exit;
    }

    // Récupération des vols + nombre de sièges de l'avion
    $sql = "
        SELECT v.refvol, v.villedepart, v.villearrive,
               v.datedepart, v.datearrivee, v.statut,
               v.idavion, a.nbsieges
        FROM vol v
        JOIN avion a ON v.idavion = a.idavion
        ORDER BY v.datedepart
    ";

    $result = pg_query($con, $sql);
    if(!$result){
        echo "Erreur lors de l'exécution de la requête";
        exit;
    }

    echo "<table border='1' cellpadding='5' cellspacing='0'>";
    echo "<tr>
            <th>Référence</th>
            <th>Ville départ</th>
            <th>Ville arrivée</th>
            <th>Date départ</th>
            <th>Date arrivée</th>
            <th>Statut</th>
            <th>Avion</th>
            <th>Remplissage</th>
            <th>Actions</th>
          </tr>";

    while($ligne = pg_fetch_array($result)){
        $refvol   = $ligne['refvol'];
        $villeDep = $ligne['villedepart'];
        $villeArr = $ligne['villearrive'];
        $dateDep  = $ligne['datedepart'];
        $dateArr  = $ligne['datearrivee'];
        $statut   = $ligne['statut'];
        $idavion  = $ligne['idavion'];
        $nbSieges = $ligne['nbsieges'];

        // Nombre de billets vendus pour ce vol
        $sql_billets = "SELECT COUNT(*) FROM billet WHERE refvol = $1";
        $res_billets = pg_query_params($con, $sql_billets, array($refvol));
        $billets_vendus = pg_fetch_result($res_billets, 0, 0);

        $remplissage = $billets_vendus . " / " . $nbSieges;

        echo "<tr>
                <td>$refvol</td>
                <td>$villeDep</td>
                <td>$villeArr</td>
                <td>$dateDep</td>
                <td>$dateArr</td>
                <td>$statut</td>
                <td>$idavion</td>
                <td>$remplissage</td>
                <td>
                    <a href='modification_vol.php?refvol=$refvol'>Modifier</a><br>
                    <a href='passager_vol.php?refvol=$refvol'>Voir les passagers</a><br>
                    <a href='equipage_vol.php?refvol=$refvol'>Équipage</a>
                </td>
              </tr>";
    }

    echo "</table>";

    pg_close($con);
    ?>

    <br>
    <a href="ajout_vol.php">Ajouter un nouveau vol</a><br>
    <a href="recherche_vol.php">Rechercher un vol</a>

    </body>
</html>
