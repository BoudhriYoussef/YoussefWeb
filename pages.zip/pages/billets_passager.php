<!DOCTYPE html>
<html>
    <head>
        <title>Billets passager</title>
        <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
    </head>
    
    <body>

    <?php
    include("connexion.php");
    $con = connect();

    if(!$con){
        echo "<p>Erreur connexion BDD.</p>";
        exit;
    }

    if(!isset($_GET['idpassager'])){
        echo "<p>Aucun passager sélectionné</p>";
        exit;
    }


    $idpass = $_GET['idpassager'];

    $sql_pass = "SELECT nom, prenom FROM passager WHERE idpassager = $1";
    $res_pass = pg_query_params($con, $sql_pass, array($idpass));

    if(pg_num_rows($res_pass)==0){
        echo "<p>PAssager non trouvé</p>";
        exit;
    }


    $passager = pg_fetch_assoc($res_pass);
    echo "<h1>Billets de {$passager['prenom']} {$passager['nom']}</h1>";

    $sql_billets = "
        SELECT b.idbillet, b.dateemission, b.numplace, b.refvol, v.villedepart, v.villearrive, v.datedepart, v.datearrivee
        FROM billet b
        JOIN vol v ON b.refvol = v.refvol
        WHERE b.idpassager = $1
        ORDER BY b.dateemission
        ";
    
    $res_billets = pg_query_params($con, $sql_billets, array($idpass));

    if(pg_num_rows($res_billets) == 0){
        echo "<p>Ce passager n'a aucun billet</p>";
    } else{
            echo "<table border='1' cellpadding='5' cellspacing='0'>";
        echo "<tr>
                <th>Numéro billet</th>
                <th>Vol</th>
                <th>Départ</th>
                <th>Arrivée</th>
                <th>Date départ</th>
                <th>Date arrivée</th>
                <th>Place</th>
                <th>Date émission</th>
            </tr>";

        while($b = pg_fetch_assoc($res_billets)){
            echo "<tr>
                    <td>{$b['idbillet']}</td>
                    <td>{$b['refvol']}</td>
                    <td>{$b['villedepart']}</td>
                    <td>{$b['villearrive']}</td>
                    <td>{$b['datedepart']}</td>
                    <td>{$b['datearrivee']}</td>
                    <td>{$b['numplace']}</td>
                    <td>{$b['dateemission']}</td>
                </tr>";
        }

        echo "</table>";
    }

    echo "<br><a href='liste_passagers.php'>Retour à la liste des passagers</a>";

    pg_close($con);

    ?>

</body>
</html>