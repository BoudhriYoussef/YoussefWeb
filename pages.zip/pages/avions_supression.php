<!DOCTYPE html>
<html>
<body>

<?php

// Connexion BD
include("connexion.php");
$connect = connect();

if (!$connect){
    echo "Erreur de connexion";
    exit;
}

// Récupération des valeurs POST
$idavion     = $_POST['idavion'];



// AJOUT DE L'AVION AVEC INSERT
$sql1 = "
    DELETE FROM avion
WHERE idavion = '$idavion';

";

$result = pg_query($connect, $sql1);

if (!$result){
    echo "<p style='color:red'>Erreur SQL : " . pg_last_error($connect) . "</p>";
    exit;
}

echo "<h2 style='color:green;'>✔ Avion supprimé avec succès !</h2>";

?>

</body>
</html>
