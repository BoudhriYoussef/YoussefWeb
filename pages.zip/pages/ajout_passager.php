<!DOCTYPE html>
<html>
<head>
    <title>Liste des passagers</title>
    <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
</head>
<body>

<?php
include("connexion.php");
$con = connect();

if (!$con) {
    echo "<p>Erreur : connexion impossible.</p>";
    exit;
}

/*
    PLAN:
    1) Sélection du vol
    2) Vérification des places disponibles
    3) Choix passager (existant / nouveau)
    4) Saisie de l'employé
    5) Ajout du billet
*/

/*******************************
 *     VARIABLES UTILISÉES
 *******************************/
$refvol_selectionne = $_POST['refvol'] ?? '';
$type_passager = $_POST['type_passager'] ?? 'existant';

$places_disponibles = []; // sera rempli après "Vérifier les places"
$liste_resultats_passagers = []; // résultats de recherche
$nb_sieges_avion = 0;


/***************************************
 *   ÉTAPE 1 + 2 : Vérifier les places
 ***************************************/
if ((isset($_POST['verifier_places']) || isset($_POST['ajouter_billet'])) 
    && $refvol_selectionne != '') {

    // récupérer l'avion utilisé par ce vol
    $sql = "SELECT idavion FROM vol WHERE refvol = $1";
    $res = pg_query_params($con, $sql, array($refvol_selectionne));

    if (pg_num_rows($res) == 0) {
        echo "<p style='color:red'>Vol introuvable.</p>";
    } else {

        $idavion = pg_fetch_result($res, 0, "idavion");

        // récupérer nombre sièges de l'avion
        $sql = "SELECT nbsieges FROM avion WHERE idavion = $1";
        $res2 = pg_query_params($con, $sql, array($idavion));

        $nb_sieges_avion = intval(pg_fetch_result($res2, 0, "nbsieges"));

        // récupérer les places déjà réservées
        $sql = "SELECT numplace FROM billet WHERE refvol = $1";
        $res3 = pg_query_params($con, $sql, array($refvol_selectionne));

        $places_prises = [];
        while ($r = pg_fetch_assoc($res3)) {
            $places_prises[] = strtoupper($r['numplace']);
        }

        // générer toutes les places possibles
        $lettres = ['A', 'B', 'C', 'D', 'E', 'F'];
        $total = $nb_sieges_avion;
        $rang = 1;

        while ($total > 0) {
            $nb_colonnes = min(6, $total);

            for ($i = 0; $i < $nb_colonnes; $i++) {
                $place = $rang . $lettres[$i];

                // si cette place n'est pas réservée -> elle est disponible
                if (!in_array($place, $places_prises)) {
                    $places_disponibles[] = $place;
                }
            }

            $total -= $nb_colonnes;
            $rang++;
        }
    }
}


/***************************************
 *   RECHERCHE PASSAGER EXISTANT
 ***************************************/
if (isset($_POST['rechercher_passager'])) {

    $nom = trim($_POST['nom_rech']);
    $prenom = trim($_POST['prenom_rech']);
    $naissance = trim($_POST['naissance_rech']);

    // recherche simple avec ILIKE (insensible à la casse)
    $sql = "SELECT idpassager, nom, prenom, naissance, numtel, mail
            FROM passager
            WHERE nom ILIKE $1 AND prenom ILIKE $2";

    $params = ['%' . $nom . '%', '%' . $prenom . '%'];

    if ($naissance !== '') {
        $sql .= " AND naissance = $3";
        $params[] = $naissance;
    }

    $res = pg_query_params($con, $sql, $params);
    $liste_resultats_passagers = pg_fetch_all($res) ?: [];
}


/***************************************
 *   AJOUT FINAL DU BILLET
 ***************************************/
if (isset($_POST['ajouter_billet'])) {

    $refvol = $_POST['refvol'];
    $idemploye = trim($_POST['idemploye']);
    $type_passager = $_POST['type_passager'];

    // vérifier vol
    if (empty($refvol)) {
        echo "<p style='color:red'>Erreur : aucun vol sélectionné.</p>";
    }
    // vérifier employé
    elseif (empty($idemploye)) {
        echo "<p style='color:red'>Erreur : ID employé requis.</p>";
    }
    else {

        // employé existe ?
        $res_emp = pg_query_params($con, "SELECT idemploye FROM employe WHERE idemploye = $1", [$idemploye]);

        if (pg_num_rows($res_emp) == 0) {
            echo "<p style='color:red'>Erreur : employé introuvable.</p>";
        } else {

            /**********************
             * PASSAGER
             **********************/
            if ($type_passager === 'existant') {

                if (empty($_POST['idpassager'])) {
                    echo "<p style='color:red'>Erreur : choisir un passager existant.</p>";
                    $idpassager = null;
                } else {
                    $idpassager = $_POST['idpassager'];
                }

            } else {

                // création nouveau passager
                $nom_new = trim($_POST['nom_new']);
                $prenom_new = trim($_POST['prenom_new']);
                $dn_new = $_POST['naissance_new'];

                if ($nom_new === '' || $prenom_new === '' || $dn_new === '') {
                    echo "<p style='color:red'>Erreur : infos passager incomplètes.</p>";
                    $idpassager = null;
                } else {

                    // générer nouvel ID 
                    $sql_num = "SELECT idpassager FROM passager ORDER BY idpassager DESC LIMIT 1"
                    $res_num = pg_query($con, $sql_num, array('P'.'%'));

                    if (pg_num_rows($res_num)==0) {
                        $num = 1;
                    } else {
                        $row = pg_fetch_array($res_num);
                        $ancien = substr($row['idpassager'], 1);
                        $num=intval($ancien) +1;
                    }

                    $num = str_pad($num, 3, "0",STR_PAD_LEFT);
                    $idpassager = 'P' . $num;

                    // insertion passager
                    $sql = "INSERT INTO passager(idpassager, nom, prenom, naissance, numtel, mail)
                            VALUES($1, $2, $3, $4, $5, $6)";

                    pg_query_params($con, $sql, [
                        $idpassager, $nom_new, $prenom_new, $dn_new,
                        $_POST['numtel'], $_POST['mail']
                    ]);
                }
            }

            // si passager ok → vérifier la place
            if (!empty($idpassager)) {

                if (empty($_POST['numplace'])) {
                    echo "<p style='color:red'>Choisis une place.</p>";
                } else {

                    $numplace = strtoupper($_POST['numplace']);

                    // place encore libre ?
                    $sql = "SELECT 1 FROM billet WHERE refvol = $1 AND numplace = $2";
                    $check = pg_query_params($con, $sql, [$refvol, $numplace]);

                    if (pg_num_rows($check) > 0) {
                        echo "<p style='color:red'>Dommage, cette place vient d'être prise.</p>";
                    } else {

                        // vérifier que le vol n'est pas plein
                        $sql = "SELECT count(*)::int AS nb FROM billet WHERE refvol = $1";
                        $res_nb = pg_query_params($con, $sql, [$refvol]);
                        $nb_res = intval(pg_fetch_result($res_nb, 0, 'nb'));

                        if ($nb_res >= $nb_sieges_avion) {
                            echo "<p style='color:red'>Le vol est complet.</p>";
                        } else {

                            // générer ID billet : B001
                            $res_maxb = pg_query($con, "SELECT idbillet FROM billet ORDER BY idbillet DESC LIMIT 1");
                            $db = pg_fetch_assoc($res_maxb);

                            if ($db && preg_match('/^B(\d+)$/', $db['idbillet'], $mb)) {
                                $n = intval($mb[1]) + 1;
                                $idbillet = 'B' . str_pad($n, 3, '0', STR_PAD_LEFT);
                            } else {
                                $idbillet = 'B001';
                            }

                            // insertion billet
                            $sql = "INSERT INTO billet(idbillet, dateemission, numplace, idpassager, refvol)
                                    VALUES($1, CURRENT_DATE, $2, $3, $4)";

                            pg_query_params($con, $sql, [
                                $idbillet, $numplace, $idpassager, $refvol
                            ]);

                            echo "<p style='color:green'><b>Billet créé :</b> $idbillet — $numplace — $idpassager</p>";
                        }
                    }
                }
            }
        }
    }
}
?>

<!-- AFFICHAGE DU FORMULAIRE -->
<form action="" method="POST" style="font-family: Arial;">

    <!-- CHOIX VOL -->
    <h3>Choisir un vol</h3>
    <select name="refvol" required>
        <option value="">-- Choisir un vol --</option>

        <?php
        $resv = pg_query($con, "SELECT refvol, villedepart, villearrive, datedepart 
                                FROM vol WHERE statut <> 'Annulé' ORDER BY datedepart");

        while ($v = pg_fetch_assoc($resv)) {
            $sel = ($refvol_selectionne == $v['refvol']) ? "selected" : "";
            echo "<option value='{$v['refvol']}' $sel>
                    {$v['refvol']} — {$v['villedepart']} → {$v['villearrive']} ({$v['datedepart']})
                  </option>";
        }
        ?>
    </select>

    <button type="submit" name="verifier_places">Vérifier les places</button>


    <!-- CHOIX TYPE PASSAGER -->
    <h3>Passager</h3>
    <label>
        <input type="radio" name="type_passager" value="existant"
            <?php if ($type_passager !== 'nouveau') echo "checked"; ?>
            onchange="this.form.submit()">
        Passager existant
    </label>

    <label style="margin-left:20px;">
        <input type="radio" name="type_passager" value="nouveau"
            <?php if ($type_passager === 'nouveau') echo 'checked'; ?>
            onchange="this.form.submit()">
        Nouveau passager
    </label>


    <!-- ========================================= -->
    <!-- PASSAGER EXISTANT -->
    <!-- ========================================= -->
    <?php if ($type_passager !== 'nouveau'): ?>

        <div style="margin-top:20px;">
            <h4>Rechercher un passager</h4>

            Nom : <input type="text" name="nom_rech">
            Prénom : <input type="text" name="prenom_rech">
            Naissance : <input type="date" name="naissance_rech">

            <button type="submit" name="rechercher_passager">Rechercher</button>
        </div>

        <?php
        if (isset($_POST['rechercher_passager'])) {
            if (empty($liste_resultats_passagers)) {
                echo "<p style='color:red;'>Aucun passager trouvé.</p>";
            } else {
                echo "<p>Résultats :</p>";
                foreach ($liste_resultats_passagers as $p) {
                    echo "<label>
                            <input type='radio' name='idpassager' value='{$p['idpassager']}'>
                            {$p['idpassager']} — {$p['nom']} {$p['prenom']} ({$p['naissance']})
                          </label><br>";
                }
            }
        }
        ?>

    <?php endif; ?>


    <!-- ========================================= -->
    <!-- NOUVEAU PASSAGER -->
    <!-- ========================================= -->
    <?php if ($type_passager === 'nouveau'): ?>
        <div style="margin-top:20px;">
            <h4>Créer un nouveau passager</h4>

            Nom : <input type="text" name="nom_new"><br><br>
            Prénom : <input type="text" name="prenom_new"><br><br>
            Naissance : <input type="date" name="naissance_new"><br><br>
            Téléphone : <input type="text" name="numtel"><br><br>
            Mail : <input type="email" name="mail"><br><br>
        </div>
    <?php endif; ?>


    <!-- ========================================= -->
    <!-- PLACES DISPONIBLES -->
    <!-- ========================================= -->
    <?php if (!empty($places_disponibles)): ?>
        <h3>Places disponibles</h3>
        <select name="numplace" required>
            <option value="">-- Choisir une place --</option>
            <?php foreach ($places_disponibles as $p): ?>
                <option value="<?= $p ?>"><?= $p ?></option>
            <?php endforeach; ?>
        </select>

    <?php elseif (isset($_POST['verifier_places']) && $refvol_selectionne != ''): ?>
        <p style="color:red;"><b>Le vol est complet.</b></p>
    <?php endif; ?>


    <!-- ÉTAPE EMPLOYÉ -->
    <h3>Employé</h3>
    <input type="text" name="idemploye" placeholder="ID employé">


    <br><br>
    <button type="submit" name="ajouter_billet">Ajouter le billet</button>

</form>

</body>
</html>
