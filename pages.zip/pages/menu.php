<link rel="stylesheet" href="style.css">
<h1>Bienvenue, que souhaitez vous voir ? </h1>
<div class="navbar">
    
    <a href="accueil.php">Accueil</a>
    <a href="avion.php">Avions</a>
    <a href="maintenance.php">Maintenance</a>
    <a href="liste_vols.php">Vols</a>
    <a href="employe.php">Employés</a>
    <a href="liste_passagers.php">Passagers</a>
</div>
