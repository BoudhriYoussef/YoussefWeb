<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="affiche_avion.css">
</head>

<body>

<?php

echo "<form method='GET' action='avions_affiche.php'>";

echo "<table border='2' width='600px'>";

echo "<tr>
        <td>Id avion</td>
        <td><input type='text' name='idavion'></td>
      </tr>";

echo "</table>";

echo "<br><input type='submit' value='Afficher l'avion'>";

echo "</form>";

?>

</body>
</html>
