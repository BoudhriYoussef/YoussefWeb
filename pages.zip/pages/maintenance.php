<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <?php include "menu.php"; ?>

    <h1>Gestion des maintenances</h1>

    <div class="form-box">
        <input type="button" value="Afficher les détails d'une maintenance" onclick="window.location.href='afficher_maintenance.php'">
        <input type="button" value="Ajouter une maintenance" onclick="window.location.href='ajouter_maintenance.php'">
        <input type="button" value="Annuler une maintenance" onclick="window.location.href='supprimer_maintenance.php'">
    </div>

</body>
</html>
