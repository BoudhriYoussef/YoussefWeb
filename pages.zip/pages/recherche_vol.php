<html>
    <head>
        <title> Recherche vols </title>
        <meta http-equiv='Content-Type' content='text/html'>
    </head>
    <body>

    <h1>Rechercher un vol</h1>

    <form method="POST">

    <label>Destination : </label>
    <input type="text" name="arrivee"><br><br>

    <label>Date de départ : </label>
    <input type="date" name="date"><br><br>

    <button type="submit" name="submit">Rechercher</button>
    <a href="vols.php">Réinitialiser</a>
    </form>

    <?php
    if(isset($_POST['submit'])){
        include("connexion.php");
        $con = connect();

        if (!$con){
            echo "Problème de connexion à la base";
            exit;
        }

        //Récupération des filtres
        $destination = $_POST['arrivee'];
        $date = $_POST['date'];

        //Construction de la requête
        $sql = "SELECT * FROM VOL WHERE 1=1";
        $params = [];
        $i = 1;

        if (!empty($destination)) {
            $sql .= " AND villearrive ILIKE $" . $i;  
            $params[] = $destination;
            $i++;
        }

        if (!empty($date)) {
            $sql .= " AND DATE(datedepart) = $" . $i;
            $params[] = $date;
            $i++;
        }

        $sql .= " ORDER BY refvol";

        // Exécution
        $result = pg_query_params($con, $sql, $params);

        if (!$result || pg_num_rows($result) == 0){
            echo "<p>Pas de vol à cette destination/date</p>";
            exit;
        }

        // Affichage
        echo "<table border='1'>";
        echo "<tr>
                <th>Référence</th>
                <th>Départ</th>
                <th>Arrivée</th>
                <th>Date départ</th>
                <th>Date arrivée</th>
                <th>Statut</th>
                <th>Avion</th>
            </tr>";

        while ($ligne = pg_fetch_array($result)) {
            echo "<tr>
                    <td>{$ligne['refvol']}</td>
                    <td>{$ligne['villedepart']}</td>
                    <td>{$ligne['villearrive']}</td>
                    <td>{$ligne['datedepart']}</td>
                    <td>{$ligne['datearrivee']}</td>
                    <td>{$ligne['statut']}</td>
                    <td>{$ligne['idavion']}</td>
                </tr>";
        }

        echo "</table>";
    }
    ?>

    </body>
</html>
