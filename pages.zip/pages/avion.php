<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <?php include "menu.php"; ?>

    <h1>Gestion des avions</h1>

    <div class="form-box">
        <input type="button" value="Afficher les détails d'un avion" onclick="window.location.href='afficher_avion.php'">
        <input type="button" value="Ajouter un avion" onclick="window.location.href='ajouter_avion.php'">
        <input type="button" value="Supprimer un avion" onclick="window.location.href='supprimer_avion.php'">
    </div>

</body>
</html>
