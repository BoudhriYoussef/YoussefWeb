<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
</head>
    <body>
        <?php
            //connexion PHP BASE DES DONNÉES //
            include("connexion.php");
            $con = connect();

            $idavion = $_GET["idavion"];
            if (!$connect){
                echo "Erreur de connexion";
                exit;
            }

            $cmdeSQL ="SELECT * FROM MAINTENANCE WHERE MAINTENANCE.idavion='$idavion'";
            $result =pg_query($connect,$cmdeSQL);
            if (!$result){
                echo "Erreur SQL\n";
                exit;
            }
            $ligne =pg_fetch_array($result);

            if (!$ligne){
                echo "<h2 class='erreur'>La maintenance n'existe plus ! </h2>";
                exit;
            }
            while ($ligne){
                echo "<div class='info-box'>";
                echo "<class='refmaint'>Réference de la maintenance  : ".$ligne["refmaint"]."<br>";
                echo "<class='date_maint'>Date de la maintenance : ".$ligne["datemaint"]."<br>";
                echo "<class='descrip'>La description : ".$ligne["description"]."<br>";
                echo "<class='idemp'>ID de l'employe responsable : ".$ligne["idemploye"]."<br><br>";
                echo "</div>";

                $ligne = pg_fetch_array($result);
            }
        ?>
    </body>
</html>
