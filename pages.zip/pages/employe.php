<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <?php include "menu.php"; ?>

    <h1>Gestion des employés</h1>

    <div class="form-box">
        <input type="button" value="Afficher les détails d'un employé" onclick="window.location.href='affiche_employe.php'">
        <input type="button" value="Ajouter un nouveau employé" onclick="window.location.href='ajout_employe.php'">
        <input type="button" value="Supprimer un employé" onclick="window.location.href='supprimer_employe.php'">
    </div>

</body>
</html>
