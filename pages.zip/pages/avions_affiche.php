<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
</head>

    <body>
        <?php
            //connexion PHP BASE DES DONNÉES //
            include("connexion.php");
            $connect = connect();
            $idavion = $_GET["idavion"];
            if (!$connect){
                echo "Erreur de connexion";
                exit;
            }

            $cmdeSQL ="SELECT * FROM AVION WHERE idavion='$idavion'";
            $result =pg_query($connect,$cmdeSQL);
            if (!$result){
                echo "Erreur SQL\n";
                exit;
            }
            $ligne =pg_fetch_array($result);

            if (!$ligne){
                echo "<h2 class='erreur'>Cet avion n'existe pas dans la base des données ou IDavion est faux</h2>";
                exit;
            }
            while ($ligne){
                echo "<div class='info-box'>";
                echo "<class='id'>ID : ".$ligne["idavion"]."<br>";
                echo "<class='siege'>Nombre de sièges : ".$ligne["nbsieges"]."<br>";
                echo "<class='type'>Type : ".$ligne["reftype"]."<br>";
                echo "<class='dateservice'>Date de mise en service : ".$ligne["miseservice"]."<br>";
                echo "<class='idcomp'>ID compagnie : ".$ligne["idca"]."<br><br>";
                echo "</div>";

                $ligne = pg_fetch_array($result);
            }
        ?>
    </body>
</html>
