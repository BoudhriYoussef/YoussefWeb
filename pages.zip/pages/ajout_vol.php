<!DOCTYPE html>
<html>
    <head>
        <title>Ajout Vol</title>
        <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
    </head>
    <body>
        <h1>Ajouter un nouveau vol</h1>
        <form action="" method="POST">

            <!--Choix de la compagnie-->
            <label>Compagnie : </label>
            <select name="idca" required>
                <option value="">Choisir une compagnie</option>

                <?php
                include("connexion.php");
                $con = connect();

                if(!$con){
                    echo "Erreur connexion";
                    exit;
                }

                // Charger les compagnies
                $sql_comp = "SELECT idca, nom FROM compagnie_aerienne ORDER BY nom";
                $res_comp = pg_query($con, $sql_comp);

                $idca_selected = isset($_POST['idca']) ? $_POST['idca'] : '';

                while($row = pg_fetch_array($res_comp)){
                    $selected = ($row['idca'] == $idca_selected) ? 'selected' : '';
                    echo "<option value='{$row['idca']}' $selected>{$row['nom']} ({$row['idca']})</option>";
                }
                ?>
            </select><br><br>


            <label>Ville de départ : </label>
            <input type="text" name="villeD" 
                value="<?php echo isset($_POST['villeD']) ? htmlspecialchars($_POST['villeD']) : '';?>" 
                required><br><br>

            <label>Ville d'arrivée : </label>
            <input type="text" name="villeA" 
                value="<?php echo isset($_POST['villeA']) ? htmlspecialchars($_POST['villeA']) : '';?>" 
                required><br><br>

            <label>Date de départ : </label>
            <input type="datetime-local" name="dateD"
                value="<?php echo isset($_POST['dateD']) ? $_POST['dateD'] : '';?>"
                required><br><br>

            <label>Date d'arrivée : </label>
            <input type="datetime-local" name="dateA"
                value="<?php echo isset($_POST['dateA']) ? $_POST['dateA'] : '';?>"
                required><br><br>


            <input type="submit" name="check_avions" value="Voir les avions disponibles"><br><br>

            <!-- Choix avion : uniquement si on a sélectionné les dates -->
            <label>Choisir un avion :</label>
            <select name="idavion" <?php echo isset($_POST['check_avions']) || isset($_POST['submit']) ? 'required' : ''; ?>>
                <option value="">Avions disponibles</option>

                <?php
                if(isset($_POST['check_avions']) || isset($_POST['submit'])){
                    if(isset($_POST['dateD']) && isset($_POST['dateA'])){
                        $dateD = $_POST['dateD'];
                        $dateA = $_POST['dateA'];

                        // Avions dispos (pas en vol à ce créneau)
                        $sql_avion = "
                            SELECT a.idavion
                            FROM avion a
                            WHERE a.idavion NOT IN (
                                SELECT idavion FROM vol
                                WHERE (
                                    datedepart <= $1 AND datearrivee >= $1
                                ) OR (
                                    datedepart <= $2 AND datearrivee >= $2
                                ) OR (
                                    datedepart >= $1 AND datearrivee <= $2
                                )
                            )
                            ORDER BY a.idavion
                        ";

                        $res_avion = pg_query_params($con, $sql_avion, array($dateD, $dateA));

                        $idavion_selected = isset($_POST['idavion']) ? $_POST['idavion'] : '';

                        if(pg_num_rows($res_avion) == 0){
                            echo "<option value=''>Aucun avion disponible</option>";
                        } else {
                            while($row = pg_fetch_array($res_avion)){
                                $selected = ($row['idavion'] == $idavion_selected) ? 'selected' : '';
                                echo "<option value='{$row['idavion']}' $selected>Avion {$row['idavion']}</option>";
                            }
                        }
                    }
                }
                ?>
            </select><br><br>

            <input type="submit" name="submit" value="Ajouter le vol"><br><br>
            <a href="liste_vols.php"><button type="button">Retour à la liste</button></a>

        </form>

        <?php
        // Traitement ajout vol
        if(isset($_POST['submit']) && isset($_POST['idavion']) && !empty($_POST['idavion'])){
            if (!$con){
                echo "<p style='color:red'><b>Problème de connexion à la base</b></p>";
                exit;
            }

            $idca = $_POST['idca'];
            $villeD = ucfirst(strtolower(trim($_POST['villeD'])));
            $villeA = ucfirst(strtolower(trim($_POST['villeA'])));
            $dateD = $_POST['dateD'];
            $dateA = $_POST['dateA'];
            $idavion = $_POST['idavion'];

            //date de départ dans le futur
            if ($dateD <= date("Y-m-d H:i")) {
                echo "<p style='color:red'><b>La date de départ doit être dans le futur.</b></p>";
                exit;
            }

            //date d'arrivée après date de départ
            if ($dateA <= $dateD) {
                echo "<p style='color:red'><b>La date d'arrivée doit être après la date de départ.</b></p>";
                exit;
            }

            //Génération RefVol
            $sql_num = "SELECT refvol FROM vol WHERE refvol LIKE $1 ORDER BY refvol DESC LIMIT 1";
            $res_num = pg_query_params($con, $sql_num, array($idca.'%'));

            if(pg_num_rows($res_num) == 0){
                $num = 1;
            } else {
                $row = pg_fetch_array($res_num);
                $ancien = substr($row['refvol'], strlen($idca));
                $num = intval($ancien) + 1;
            }

            $num = str_pad($num, 3, "0", STR_PAD_LEFT);
            $refvol = $idca . $num;


            $villes_valides = array(
                "Paris", "Lyon", "Toulouse", "Marseille", "Nice",
                "Bordeaux", "Nantes", "Lille", "Strasbourg", "Rennes"
            );

            if(!in_array($villeD, $villes_valides)){
                echo "<p style='color:red'><b>La ville de départ '$villeD' n'existe pas dans la liste.</b></p>";
                echo "<p>Villes valides : " . implode(", ", $villes_valides) . "</p>";
                exit;
            }

            if(!in_array($villeA, $villes_valides)){
                echo "<p style='color:red'><b>La ville d'arrivée '$villeA' n'existe pas dans la liste.</b></p>";
                echo "<p>Villes valides : " . implode(", ", $villes_valides) . "</p>";
                exit;
            }

            if($villeD == $villeA){
                echo "<p style='color:red'><b>La ville de départ et d'arrivée doivent être différentes.</b></p>";
                exit;
            }


            $sql_insert = "
                INSERT INTO vol(refvol, villedepart, villearrive, datedepart, datearrivee, statut, idavion)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
            ";

            $res_insert = pg_query_params($con, $sql_insert,
                array($refvol, $villeD, $villeA, $dateD, $dateA, 'Programmé', $idavion));

            if($res_insert){
                echo "<div style='color:green; border: 2px solid green; padding: 10px; margin: 10px 0;'>";
                echo "<h3>✓ Vol ajouté avec succès !</h3>";
                echo "<p><strong>Référence :</strong> $refvol<br>";
                echo "<strong>Compagnie :</strong> $idca<br>";
                echo "<strong>Avion :</strong> $idavion<br>";
                echo "<strong>Départ :</strong> $villeD le $dateD<br>";
                echo "<strong>Arrivée :</strong> $villeA le $dateA</p>";
                echo "</div>";
            } else {
                echo "<p style='color:red'><b>Erreur lors de l'insertion :</b> ".pg_last_error($con)."</p>";
            }
        } elseif(isset($_POST['submit'])){
            echo "<p style='color:orange'><b>Veuillez d'abord vérifier les avions disponibles.</b></p>";
        }
        ?>

    </body>
</html>