<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Accueil - Gestion Compagnie Aérienne</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f3f6fa;
            margin: 0;
            padding: 0;
        }
        .header {
            background: #1f6feb;
            padding: 15px;
            color: white;
            font-size: 24px;
            text-align: center;
        }
        .menu {
            background: #2d333b;
            padding: 10px 0;
            text-align: center;
        }
        .menu a {
            margin: 0 20px;
            color: #c9d1d9;
            text-decoration: none;
            font-size: 18px;
        }
        .menu a:hover {
            color: #58a6ff;
        }
        .container {
            margin: 40px auto;
            width: 80%;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }
        th, td {
            border: 1px solid #e1e4e8;
            padding: 10px;
            text-align: center;
        }
        th {
            background: #f6f8fa;
        }
    </style>
</head>

<body>

<div class="header">✈ Informations & Opérations Sur Une Compagnie Aériennes</div>

<div class="menu">
    <a href="interface_accueil.php">Accueil</a>
    <a href="avion.php">Avions</a>
    <a href="maintenance.php">Maintenance</a>
    <a href="vols.php">Vols</a>
    <a href="employe.php">Employés</a>
    <a href="passager.php">Passagers</a>
</div>

<div class="container">
    <h2>Liste des avions</h2>

    <?php
    // Connexion BD
    $connect = pg_connect("host=serveur-etu.polytech-lille.fr user=yboudhri password=postgres dbname=projet_bd");

    if (!$connect){
        echo "<p style='color:red'>Erreur de connexion</p>";
        exit;
    }

    $sql = "SELECT idavion, nbsieges, reftype, miseservice, idca FROM avion ORDER BY idavion";
    $result = pg_query($connect, $sql);

    echo "<table>";
    echo "<tr>
            <th>Identifiant</th>
            <th>Nb de sièges</th>
            <th>Type</th>
            <th>Date de service</th>
            <th>Compagnie</th>
          </tr>";

    while ($row = pg_fetch_array($result)) {
        echo "<tr>
                <td>".$row['idavion']."</td>
                <td>".$row['nbsieges']."</td>
                <td>".$row['reftype']."</td>
                <td>".$row['miseservice']."</td>
                <td>".$row['idca']."</td>
            </tr>";
    }

    echo "</table>";
    ?>
</div>

</body>
</html>
