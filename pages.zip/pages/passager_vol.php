<!DOCTYPE html>
<html>
    <head>
        <title>Passagers du vol</title>
        <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
    </head>
    
    <body>
    <?php
        include("connexion.php");
        $con = connect();

        if(!$con){
            echo "<p>Erreur de connexion à la base.</p>";
            exit;
        }

        if(!isset($_GET['refvol'])){
            echo "<p>Aucun vol sélectionné.</p>";
            exit;
        }

        $refvol = $_GET['refvol'];

        $sql_vol = "SELECT * FROM vol WHERE refvol = $1";
        $res_vol = pg_query_params($con, $sql_vol, array($refvol));

        if(pg_num_rows($res_vol) == 0){
            echo "<p>Vol introuvable.</p>";
            exit;
        }

        $vol = pg_fetch_assoc($res_vol);

        echo "<h1>Passagers du vol ".$vol['refvol']."</h1>";
        echo "<p><strong>Trajet : </strong>".$vol['villedepart']."->".$vol['villearrive']."</p>";
        echo "<p><strong>Départ : </strong>".$vol['datedepart']."</p>";
        echo "<p><strong>Arrivée : </strong>".$vol['datearrivee']."</p><br>";

        $sql_passagers = "SELECT p.idpassager, p.nom, p.prenom, p.naissance, p.numtel, p.mail, b.numplace
                        FROM passager p
                        JOIN billet b ON p.idpassager = b.idpassager
                        WHERE b.refvol = $1
                        ";

        $res_passagers = pg_query_params($con, $sql_passagers, array($refvol));

        if(pg_num_rows($res_passagers)==0){
            echo "<p>Aucun passager pour ce vol.</p>";
        } else {
            
            echo "<table border='1' cellpadding='5' cellspacing='0'>";
            echo "<tr>
                    <th>ID Passager</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Date de naissance</th>
                    <th>Téléphone</th>
                    <th>Email</th>
                    <th>Numéro de place</th>
                </tr>";

            while($row = pg_fetch_assoc($res_passagers)){
                echo "<tr>
                        <td>".$row['idpassager']."</td>
                        <td>".$row['nom']."</td>
                        <td>".$row['prenom']."</td>
                        <td>".$row['naissance']."</td>
                        <td>".$row['numtel']."</td>
                        <td>".$row['mail']."</td>
                        <td>".$row['numplace']."</td>
                    </tr>";
            }
            echo "</table>";
        }
    ?>
     <p><br><a href="liste_vols.php">Retour à la liste des vols</a></p>

</body>
</html>           