<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<?php

include("connexion.php");
$connect = connect();

if (!$connect){
    echo "Erreur de connexion";
    exit;
}
echo "<form method='POST' action='maintenance_supression.php'>";

?>

<table border='2' width='600px'>

<tr>
        <td> Id de la maintenance à annuler </td>
        <td>
            <select name="refmaint" size="1">
                <?php
                $sql = "SELECT refmaint FROM MAINTENANCE";
                $result = pg_query($connect, $sql);

                while ($row = pg_fetch_array($result)) {
                    echo "<option value='".$row['refmaint']."'>".$row['refmaint']."</option>";
                }
                ?>
            </select>
        </td>
</tr>

</table>
<br><input type='submit' value='Annule la maintenance'>

</form>



</body>
</html>
