<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<?php
// Connexion BD
include("connexion.php");
$connect = connect();

if (!$connect){
    echo "<p style='color:red'>Erreur de connexion</p>";
    exit;
}
?>

<form method="GET" action="maintenance_affiche.php">

<table border="2" width="600px">

    <tr>
        <td> Id de l'avion pour consulter sa maintenance </td>
        <td>
            <select name="idavion" size="1">
                <?php
                $sql = "SELECT DISTINCT idavion FROM MAINTENANCE";
                $result = pg_query($connect, $sql);

                while ($row = pg_fetch_array($result)) {
                    echo "<option value='".$row['idavion']."'>".$row['idavion']."</option>";
                }
                ?>
            </select>
        </td>
    </tr>

</table>

<br>
<input type="submit" value="Afficher la maintenance correspondante">

</form>

</body>
</html>
