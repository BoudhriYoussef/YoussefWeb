<!DOCTYPE html>
<html>
<body>

<?php
include("connexion.php");
$connect = connect();

if (!$connect){
    echo "Erreur de connexion";
    exit;
}
?>
<form method="POST" action="maintenance_ajout.php">

<table border="2" width="600px">

  <tr>
        <td>Date de maintenance</td>
        <td><input type="date" name="date_maint"></td>
    </tr>

        <td>Description de la maintenance</td>
        <td><input type="text" name="maintdescrip"></td>
    </tr>

    <tr>
        <td> ID avion </td>
        <td>
            <select name="idavion" size="1">
                <?php
                $sql2 = "SELECT idavion FROM AVION";
                $result = pg_query($connect, $sql2);

                while ($row = pg_fetch_array($result)) {
                    echo "<option value='".$row['idavion']."'>".$row['idavion']."</option>";
                }
                ?>
            </select>
        </td>
    </tr>

    <tr>
        <td> ID employé responsable </td>
        <td>
            <select name="idemploye" size="1">
                <?php
                $sql2 = "SELECT idemploye FROM EMPLOYE";
                $result = pg_query($connect, $sql2);

                while ($row = pg_fetch_array($result)) {
                    echo "<option value='".$row['idemploye']."'>".$row['idemploye']."</option>";
                }
                ?>
            </select>
        </td>
    </tr>


</table>

<br>
<input type="submit" value="Ajouter Maintenance">


</form>

</body>
</html>



