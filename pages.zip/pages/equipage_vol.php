<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Gestion équipage vol</title>
</head>
<body>

<h1>Gestion de l’équipage du vol</h1>

<?php
include("connexion.php");
$con = connect();

if(!$con){
    echo "Erreur connexion base";
    exit;
}

if(!isset($_GET['refvol'])){
    echo "Aucun vol sélectionné";
    exit;
}

$refvol = $_GET['refvol'];


// =========================
// 1. RÉCUPÉRATION DU VOL
// =========================
$sql_vol = "
    SELECT v.refvol, v.statut, v.datedepart, v.datearrivee,
           a.nbsieges, a.idca
    FROM vol v
    JOIN avion a ON v.idavion = a.idavion
    WHERE v.refvol = $1
";
$res_vol = pg_query_params($con, $sql_vol, array($refvol));

if(pg_num_rows($res_vol) == 0){
    echo "Vol introuvable";
    exit;
}

$vol = pg_fetch_assoc($res_vol);

if($vol['statut'] == 'Annulé'){
    echo "<p>Vol annulé : modification de l’équipage interdite</p>";
    exit;
}

$nbSieges = $vol['nbsieges'];
$idCompagnie = $vol['idca'];


// =========================
// 2. BESOINS ÉQUIPAGE
// =========================
$nbHotessesRequises = ceil($nbSieges / 50);

$besoins = array(
    'PIL' => 1,
    'COP' => 1,
    'HOT' => $nbHotessesRequises
);

echo "<h2>Besoins de l’équipage</h2>";

foreach($besoins as $fonction => $requis){
    $sql = "
        SELECT COUNT(*)
        FROM equipage eq
        JOIN employe e ON eq.idemploye = e.idemploye
        WHERE eq.refvol = $1 AND e.idfonc = $2
    ";
    $res = pg_query_params($con, $sql, array($refvol, $fonction));
    $actuel = pg_fetch_result($res, 0, 0);

    echo "<p>$fonction : $actuel / $requis</p>";
}


// =========================
// 3. AJOUT EMPLOYÉ
// =========================
if(isset($_POST['ajouter_employe'])){

    $idemploye = $_POST['idemploye'];

    // Fonction de l'employé
    $sql_fonc = "SELECT idfonc FROM employe WHERE idemploye = $1";
    $res_fonc = pg_query_params($con, $sql_fonc, array($idemploye));

    if(pg_num_rows($res_fonc) == 0){
        echo "Employé invalide";
        exit;
    }

    $fonction = pg_fetch_result($res_fonc, 0, 0);

    // Nombre actuel pour cette fonction
    $sql_nb = "
        SELECT COUNT(*)
        FROM equipage eq
        JOIN employe e ON eq.idemploye = e.idemploye
        WHERE eq.refvol = $1 AND e.idfonc = $2
    ";
    $res_nb = pg_query_params($con, $sql_nb, array($refvol, $fonction));
    $actuel = pg_fetch_result($res_nb, 0, 0);

    if($actuel >= $besoins[$fonction]){
        echo "Nombre maximum atteint pour $fonction";
        exit;
    }

    // Vérifier si l'employé est déjà dans l'équipage de ce vol
    $sql_existe = "
        SELECT 1
        FROM equipage
        WHERE idemploye = $1 AND refvol = $2
    ";
    $res_existe = pg_query_params($con, $sql_existe, array($idemploye, $refvol));

    if(pg_num_rows($res_existe) > 0){
        echo "<p>Cet employé est déjà affecté à ce vol.</p>";
        exit;
    }


    // Insertion
    $sql_ins = "INSERT INTO equipage(idemploye, refvol) VALUES ($1, $2)";
    $res_ins = pg_query_params($con, $sql_ins, array($idemploye, $refvol));

    if($res_ins){
        echo "<p>Employé ajouté à l’équipage</p>";
    } else {
        echo "Erreur ajout équipage";
    }
}


// =========================
// 4. EMPLOYÉS DISPONIBLES
// =========================
echo "<h2>Ajouter un employé</h2>";

$sql_employes = "
SELECT e.idemploye, e.nom, e.prenom, e.idfonc
FROM employe e
WHERE e.idca = $1
AND e.idfonc IN ('PIL','COP','HOT')
AND e.idemploye NOT IN (
    SELECT eq.idemploye
    FROM equipage eq
    JOIN vol v ON eq.refvol = v.refvol
    WHERE v.datedepart < $2
    AND v.datearrivee > $3
)
AND e.idemploye NOT IN (
    SELECT idemploye FROM equipage WHERE refvol = $4
)
ORDER BY e.idfonc, e.nom
";

$res_emp = pg_query_params(
    $con,
    $sql_employes,
    array(
        $idCompagnie,
        $vol['datearrivee'],
        $vol['datedepart'],
        $refvol
    )
);

if(pg_num_rows($res_emp) == 0){
    echo "<p>Aucun employé disponible</p>";
} else {
    echo "<form method='POST'>";
    echo "<select name='idemploye' required>";
    echo "<option value=''>Choisir un employé</option>";

    while($e = pg_fetch_assoc($res_emp)){
        echo "<option value='{$e['idemploye']}'>
            {$e['idfonc']} - {$e['nom']} {$e['prenom']} ({$e['idemploye']})
        </option>";
    }

    echo "</select><br><br>";
    echo "<input type='submit' name='ajouter_employe' value='Ajouter à l’équipage'>";
    echo "</form>";
}


// =========================
// 5. AFFICHAGE ÉQUIPAGE
// =========================
echo "<h2>Équipage actuel</h2>";

$sql_eq = "
    SELECT e.idemploye, e.nom, e.prenom, e.idfonc
    FROM equipage eq
    JOIN employe e ON eq.idemploye = e.idemploye
    WHERE eq.refvol = $1
    ORDER BY e.idfonc
";
$res_eq = pg_query_params($con, $sql_eq, array($refvol));

if(pg_num_rows($res_eq) == 0){
    echo "<p>Aucun membre dans l’équipage</p>";
} else {
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Nom</th><th>Prénom</th><th>Fonction</th></tr>";

    while($row = pg_fetch_assoc($res_eq)){
        echo "<tr>
            <td>{$row['idemploye']}</td>
            <td>{$row['nom']}</td>
            <td>{$row['prenom']}</td>
            <td>{$row['idfonc']}</td>
        </tr>";
    }

    echo "</table>";
}

?>

<br>
<a href="liste_vols.php">⬅ Retour à la liste des vols</a>

</body>
</html>
