<!DOCTYPE html>
<html>
<body>

<?php
include("connexion.php");
$connect = connect();

if (!$connect){
    echo "Erreur de connexion";
    exit;
}
?>
<form method="POST" action="avions_ajout.php">

<table border="2" width="600px">

  <tr>
        <td> Nom de Compagnie (idca)</td>
        <td>
            <select name="idca" size="1">
                <?php
                $sql1 = "SELECT idca FROM COMPAGNIE_AERIENNE";
                $result = pg_query($connect, $sql1);

                while ($row = pg_fetch_array($result)) {
                    echo "<option value='".$row['idca']."'>".$row['idca']."</option>";
                }
                ?>
            </select>
        </td>


    <tr>
        <td>Nombre de sièges</td>
        <td><input type="text" name="nbsieges"></td>
    </tr>

    <tr>
        <td> Type de l'avion </td>
        <td>
            <select name="reftype" size="1">
                <?php
                $sql2 = "SELECT reftype FROM TYPE_AVION";
                $result = pg_query($connect, $sql2);

                while ($row = pg_fetch_array($result)) {
                    echo "<option value='".$row['reftype']."'>".$row['reftype']."</option>";
                }
                ?>
            </select>
        </td>
    </tr>

    <tr>
        <td>Date de mise en service</td>
        <td><input type="date" name="date_service"></td>
    </tr>

</table>

<br>
<input type="submit" value="Ajouter avion">


</form>

</body>
</html>

		
