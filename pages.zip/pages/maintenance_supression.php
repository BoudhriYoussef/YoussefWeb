<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<?php

// Connexion BD
include("connexion.php");
$connect = connect();

if (!$connect){
    echo "Erreur de connexion";
    exit;
}

// Récupération des valeurs POST
$refmaint    = $_POST['refmaint'];



// AJOUT DE L'AVION AVEC INSERT
$sql1 = "
    DELETE FROM maintenance
WHERE refmaint = '$refmaint';

";

$result = pg_query($connect, $sql1);

if (!$result){
    echo "<p style='color:red'>Erreur SQL : " . pg_last_error($connect) . "</p>";
    exit;
}

echo "<h2 style='color:green;'>✔ Maintenance supprimée avec succès !</h2>";

?>

</body>
</html>
