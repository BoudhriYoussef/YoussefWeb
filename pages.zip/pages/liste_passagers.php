<!DOCTYPE html>
<html>
    <head>
        <title>Liste des passagers</title>
        <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
    </head>
    
    <body>

    <h1>Liste des passagers</h1>

    <?php
    include("connexion.php");
    $con = connect();

    if(!$con){
        echo "<p>Erreur connexion à la base</p>";
        exit;
    }

    $sql = "SELECT idpassager, nom, prenom, naissance, numtel, mail FROM passager ORDER BY nom, prenom";
    $res = pg_query($con, $sql);

    if(!$res){
        echo "<p>Erreur lors de la récupération des passagers.</p>";
        exit;
    }

    echo "<table border='1' cellpadding='5' cellspacing='0'>";
    echo "<tr>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Naissance</th>
            <th>Téléphone</th>
            <th>Email</th>
            <th>Actions</th>
        </tr>";

    while($passager = pg_fetch_assoc($res)){
        $id = $passager['idpassager'];
        echo "<tr>
                <td>{$passager['nom']}</td>
                <td>{$passager['prenom']}</td>
                <td>{$passager['naissance']}</td>
                <td>{$passager['numtel']}</td>
                <td>{$passager['mail']}</td>
                <td><a href='billets_passager.php?idpassager=$id'>Voir billets</a></td>
            </tr>";
    }

    echo "</table>";



    pg_close($con);
    ?>
    
    <p><a href="ajout_passager.php">Ajouter un passager</a></p>

</body>
</html>