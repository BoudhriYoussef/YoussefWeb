<!DOCTYPE html>
<html>
    <head>
        <title>Modifier un vol</title>
        <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
    </head>
    
    <body>

    <?php
        include("connexion.php");
        $con = connect();

        if(!$con){
            echo "<p>Erreur de connexion à la base.</p>";
            exit;
        }

        if(!isset($_GET['refvol'])){
            echo "<p>Aucun vol sélectionné.</p>";
            exit;
        }

        $refvol = $_GET['refvol'];

        $sql_vol = "SELECT * FROM vol WHERE refvol = $1";
        $res_vol = pg_query_params($con, $sql_vol, array($refvol));

        if(pg_num_rows($res_vol) == 0){
            echo "<p>Vol introuvable.</p>";
            exit;
        }

        $vol = pg_fetch_array($res_vol);

        if($vol['statut'] == 'Annulé'){
            echo "<p style='color:red;'>Ce vol est annulé et ne peut plus être modifié.</p>";
            echo "<a href='liste_vols.php'><button type='button'>Retour</button></a>";
            exit; 
        }
    ?>

    <h1>Modifier le vol <?php echo htmlspecialchars($refvol); ?></h1>

    <form method="POST">
        <input type="hidden" name="refvol" value="<?php echo htmlspecialchars($refvol); ?>">
        
        <label>Référence :</label>
        <input type="text" value="<?php echo htmlspecialchars($vol['refvol']); ?>" disabled><br><br>

        <label>Ville de départ :</label>
        <input type="text" value="<?php echo htmlspecialchars($vol['villedepart']); ?>" disabled><br><br>

        <label>Ville d'arrivée :</label>
        <input type="text" value="<?php echo htmlspecialchars($vol['villearrive']); ?>" disabled><br><br>

        <label>Date de départ :</label>
        <input type="datetime-local" name="datedepart"
            value="<?php echo date('Y-m-d\TH:i', strtotime($vol['datedepart'])); ?>" required><br><br>

        <label>Date d'arrivée :</label>
        <input type="datetime-local" name="datearrivee"
            value="<?php echo date('Y-m-d\TH:i', strtotime($vol['datearrivee'])); ?>" required><br><br>

        <label>Avion :</label>
        <select name="idavion" required>
            <option value="">-- Choisir un avion disponible --</option>
            <?php
            $sql_avion = "
                SELECT idavion FROM avion
                WHERE idavion = $1 OR idavion NOT IN (
                    SELECT idavion FROM vol
                    WHERE refvol != $2
                    AND (
                            (datedepart <= $3 AND datearrivee >= $3)
                        OR (datedepart <= $4 AND datearrivee >= $4)
                        OR (datedepart >= $3 AND datearrivee <= $4)
                    )
                )
            ";
            $res_avion = pg_query_params($con, $sql_avion, array(
                $vol['idavion'], $refvol, $vol['datedepart'], $vol['datearrivee']
            ));

            while($a = pg_fetch_array($res_avion)){
                $selected = ($a['idavion'] == $vol['idavion']) ? "selected" : "";
                echo "<option value='".htmlspecialchars($a['idavion'])."' $selected>".htmlspecialchars($a['idavion'])."</option>";
            }
            ?>
        </select><br><br>

        <input type="submit" name="modifier" value="Mettre à jour">
        
        <a href="suppression_vol.php?refvol=<?php echo urlencode($refvol); ?>">
            <button type="button" 
                    onclick="if(confirm('Voulez-vous vraiment annuler ce vol ?')){ 
                                window.location='suppression_vol.php?refvol=<?php echo $refvol; ?>'; 
                            }">
                Annuler ce vol
            </button>
        </a><br><br>
        
        <a href="liste_vols.php"><button type="button">Retour à la liste</button></a>
        
    </form>

    <?php
    if(isset($_POST['modifier'])){
        $new_dep = $_POST['datedepart'];
        $new_arr = $_POST['datearrivee'];
        $new_avion = $_POST['idavion'];

        // Vérifier que la date d'arrivée est bien après le départ
        if(strtotime($new_arr) <= strtotime($new_dep)){
            echo "<p style='color:red;'>Erreur : la date d'arrivée doit être après la date de départ.</p>";
        } else {
            // Calculer le statut
            $ancienne_dep = strtotime($vol['datedepart']);
            $nouvelle_dep = strtotime($new_dep);
            
            if($nouvelle_dep > $ancienne_dep){
                $new_statut = "Retardé";
            } else {
                $new_statut = "Programmé";
            }

            $sql_update = "
                UPDATE vol
                SET datedepart = $1,
                    datearrivee = $2,
                    idavion = $3,
                    statut = $4
                WHERE refvol = $5
            ";
            $res_update = pg_query_params($con, $sql_update, array(
                $new_dep, $new_arr, $new_avion, $new_statut, $refvol
            ));

            if($res_update){
                echo "<p style='color:green;'>Vol mis à jour avec succès.</p>";
                // Recharger les données du vol
                $res_vol = pg_query_params($con, $sql_vol, array($refvol));
                $vol = pg_fetch_array($res_vol);
            } else {
                echo "<p style='color:red;'>Erreur lors de la mise à jour : ".htmlspecialchars(pg_last_error($con))."</p>";
            }
        }
    }
    ?>

    </body>
</html>