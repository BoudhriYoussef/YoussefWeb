<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
</head>

    <body>
        <?php
            //connexion PHP BASE DES DONNÉES //
            include("connexion.php");
            $connect = connect();
            $idemploye = $_GET["idemploye"];
            if (!$connect){
                echo "Erreur de connexion";
                exit;
            }

            $cmdeSQL ="SELECT * FROM EMPLOYE WHERE EMPLOYE.idemploye='$idemploye'";
            $result =pg_query($connect,$cmdeSQL);
            if (!$result){
                echo "Erreur SQL\n";
                exit;
            }
            $ligne =pg_fetch_array($result);

            if (!$ligne){
                echo "<h2 class='erreur'>L'employé ne travaille plus dans cette compagnie ! </h2>";
                exit;
            }
            while ($ligne){
                echo "<div class='info-box'>";
                echo "<class='idemploye'>ID de l'employé  : ".$ligne["idemploye"]."<br>";
                echo "<class='nom'>Nom d'employé : ".$ligne["nom"]."<br>";
                echo "<class='prenom'>Prénom d'employé: ".$ligne["prenom"]."<br>";
                echo "<class='numtel'>Numéro téléphone de l'employe: ".$ligne["numtel"]."<br>";
                echo "<class='idca'>ID de la compagnie aérienne correspondante: ".$ligne["idca"]."<br>";
                echo "<class='idfonc'>ID de fonction d'employé: ".$ligne["idfonc"]."<br><br>";
                echo "</div>";

                $ligne = pg_fetch_array($result);
            }
        ?>
    </body>
</html>
